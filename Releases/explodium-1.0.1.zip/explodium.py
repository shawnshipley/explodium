bl_info = {
    "name": "Exploded View",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > N-Panel > Edit",
    "description": "Show mesh in exploded view",
    "category": "Mesh",
}

import bpy
from bpy.types import Operator, Panel, AddonPreferences
from bpy.props import FloatProperty, BoolProperty

# Addon Preferences for Keymap
class ExplodedViewPreferences(AddonPreferences):
    bl_idname = __name__

    def draw(self, context):
        layout = self.layout
        layout.label(text="Keyboard Shortcuts:")
        
        # Display current keymaps
        wm = bpy.context.window_manager
        kc = wm.keyconfigs.user
        
        for km, kmi in addon_keymaps:
            layout.context_pointer_set("keymap", km)
            rna_keymap_ui.draw_kmi([], kc, km, kmi, layout, 0)


# Operator
class MESH_OT_exploded_view(Operator):
    """Toggle exploded view of mesh"""
    bl_idname = "mesh.exploded_view"
    bl_label = "Exploded View"
    bl_options = {'REGISTER', 'UNDO'}

    explode_factor: FloatProperty(
        name="Explode Factor",
        description="Distance to explode faces",
        default=0.5,
        min=0.0,
        max=10.0,
    )

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        
        # Your exploded view logic here
        # (I'm assuming you have the actual implementation)
        
        self.report({'INFO'}, f"Exploded view applied with factor {self.explode_factor}")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


# N-Panel
class VIEW3D_PT_exploded_view(Panel):
    """Creates a Panel in the N-Panel under Edit tab"""
    bl_label = "Exploded View"
    bl_idname = "VIEW3D_PT_exploded_view"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Edit'  # This puts it in the Edit tab

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        # Check if we have a mesh object
        if obj and obj.type == 'MESH':
            layout.operator("mesh.exploded_view", text="Apply Exploded View")
            
            # You can add more UI elements here
            # For example, a property for the explode factor:
            # layout.prop(context.scene, "explode_factor")
        else:
            layout.label(text="Select a mesh object", icon='INFO')


# Keymap storage
addon_keymaps = []


def register():
    # Import keymap UI module
    try:
        from bl_ui.space_userpref import rna_keymap_ui
        globals()['rna_keymap_ui'] = rna_keymap_ui
    except ImportError:
        pass

    # Register classes
    bpy.utils.register_class(ExplodedViewPreferences)
    bpy.utils.register_class(MESH_OT_exploded_view)
    bpy.utils.register_class(VIEW3D_PT_exploded_view)

    # Add keymap
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
        kmi = km.keymap_items.new(
            MESH_OT_exploded_view.bl_idname,
            type='P',
            value='PRESS',
            ctrl=True,
            shift=True
        )
        addon_keymaps.append((km, kmi))


def unregister():
    # Remove keymap
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    # Unregister classes
    bpy.utils.unregister_class(VIEW3D_PT_exploded_view)
    bpy.utils.unregister_class(MESH_OT_exploded_view)
    bpy.utils.unregister_class(ExplodedViewPreferences)


if __name__ == "__main__":
    register()